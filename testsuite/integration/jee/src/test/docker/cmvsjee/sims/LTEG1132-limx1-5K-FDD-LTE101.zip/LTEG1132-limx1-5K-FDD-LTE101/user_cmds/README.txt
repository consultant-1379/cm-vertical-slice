NOTE! This directory is the storage place for user-defined
command DIRECTORIES common to the current simulation.

To add user-defined commands, printouts, etc. do as follows:
1. Create a directory on this directory
2. Copy your user-defined commands, etc. to the new directory
3. Modify the NE property "User-defined cmd directories"
   of the simulated NEs that shall use the new user-defined
   command directory.

If you put user-defined commands on the same directory as
this README.txt file, you cannot use them.
